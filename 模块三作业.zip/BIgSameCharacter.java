package com.lagou.moduleThree.work;

import java.util.Scanner;

/**
 * 获取两个指定字符串中的最大相同子串。
 */
public class BIgSameCharacter {
    public static void main(String[] args) {
        Scanner str = new Scanner(System.in);
        System.out.println("请输入两个字符串：");
        String arr1 = str.next();
        String arr2 = str.next();
        String result = findSameCharacter(arr1,arr2);
        System.out.println("最大公共子串为"+result);

    }
    public static String findSameCharacter(String str1,String str2){
        //用max获取字符串长度较大的（大串），min获取字符串长度较小的（小串）
        String max=(str1.length()>=str2.length())?str1:str2;
        String min=(max==str1)?str2:str1;
        //用i来控制小串的长度依次递减
        for(int i=0;i<min.length();i++){
            //用j,k来控制每次获取小串的子串下标范围
            for(int j=0,k=min.length()-i;k!=min.length()+1;j++,k++){
                String temp = min.substring(j,k);
                if(max.contains(temp))
                    return temp;
            }
        }
        return null;
    }
}
