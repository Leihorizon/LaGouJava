package com.lagou.moduleThree.work;

/**
 * 统计字符串"ABCD123!@#$%ab"中大写字母、小写字母、数字、其它字符的个数
 */
public class CountCharacter {
    public static void main(String[] args) {
        String str = "ABCD123!@#$%ab";
        StringBuffer bigChar = new StringBuffer();
        StringBuffer smallChar = new StringBuffer();
        StringBuffer numberChar = new StringBuffer();
        StringBuffer otherChar = new StringBuffer();
        //遍历字符串
        for(int i=0;i<str.length();i++){
            //判断字符是否是小写字母
            if(str.charAt(i)>='a'&&str.charAt(i)<='z')
                smallChar.append(str.charAt(i));
            //判断字符是否是大写字母
            else if(str.charAt(i)>='A'&&str.charAt(i)<='Z')
                bigChar.append(str.charAt(i));
            //判断字符是否是数字字符
            else if(str.charAt(i)>='0'&&str.charAt(i)<='9')
                numberChar.append(str.charAt(i));
            //判断字符是否是其它字符
            else
                otherChar.append(str.charAt(i));
        }
        System.out.println("大写字母个数:"+bigChar.length()+",大写字母分别是"+bigChar);
        System.out.println("小写字母个数:"+smallChar.length()+",小写字母分别是"+smallChar);
        System.out.println("数字字母个数:"+numberChar.length()+",数字字母分别是"+numberChar);
        System.out.println("其它字母个数:"+otherChar.length()+",其它字母分别是"+otherChar);
    }
}
