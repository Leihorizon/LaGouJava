package com.lagou.moduleThree.work.student;

import java.util.List;

/**
 * 学生信息删除
 */
public class DeleteStudent {
    /**
     * 根据学号进行删除
     * @param list
     * @param code
     * @return
     */
    public static List<Student> delete(List<Student> list, String code){
        for (Student stu:list) {
            if(code.equals(stu.getCode())) {
                list.remove(stu);
                break;
            }
        }
        return list;
    }
}
