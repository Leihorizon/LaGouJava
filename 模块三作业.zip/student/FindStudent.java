package com.lagou.moduleThree.work.student;

import java.util.List;

/**
 * 查找学生信息
 */
public class FindStudent {
    /**
     * 查找所有学生所有信息
     * @param list
     */
    public static void findAll(List<Student> list){
        for (Student stu:list) {
            System.out.println(stu.toString());
        }
    }
    /**
     * 根据学号查找学生
     */
    public static void findByCode(List<Student> list,String code){
        for (Student stu:list) {
            if(code.equals(stu.getCode()))
                System.out.println("你所查找的学生信息为："+stu.toString());
        }
    }
    /**
     * 根据名字查找学生
     */
    public static void findByName(List<Student> list,String name){
        for (Student stu:list) {
            if(name.equals(stu.getName()))
                System.out.println("你所查找的学生信息为："+stu.toString());
        }
    }
}
