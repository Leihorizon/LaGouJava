package com.lagou.moduleThree.work.student;

import java.util.List;

/**
 * 修改学生信息
 */
public class UpdateStudent {
    /**
     * 根据学号修改学生信息，需要传入学号和修改后的学生信息
     * @param list
     * @param student
     * @param code
     * @return
     */
    public static List<Student> update(List<Student> list, Student student,String code){
        for (Student stu:list) {
            if(code.equals(stu.getCode())) {
                stu.setCode(student.getCode());
                stu.setName(student.getName());
                stu.setAge(student.getAge());
                break;
            }

        }
        return list;
    }
}
