package com.lagou.moduleThree.work.student;

/**
 * 学生实体类
 */
public class Student {
    /**
     * 学号
     */
    private String code;
    /**
     * 姓名
     */
    private String name;
    /**
     * 年龄
     */
    private int age;

    public Student(String code, String name, int age) {
        this.code = code;
        this.name = name;
        this.age = age;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "学生信息{" +
                "学号：'" + code + '\'' +
                ", 姓名：'" + name + '\'' +
                ", 年龄：" + age +
                '}';
    }
}
