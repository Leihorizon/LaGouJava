package com.lagou.moduleThree.work.student;

import java.util.List;

/**
 * 增加学生信息
 */
public class AddStudent {
    /**
     * 增加学生
     * @param list
     * @param student
     * @return
     */
    public static List<Student> add(List<Student> list,Student student){
        list.add(student);
        return list;
    }

}
