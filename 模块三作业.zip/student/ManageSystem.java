package com.lagou.moduleThree.work.student;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 管理系统
 */
public class ManageSystem {
    public static void main(String[] args) {

        Scanner action = new Scanner(System.in);
        List<Student> list =new ArrayList<>();
        //初始化list，放入一部分数据
        Student student1 = new Student("001","张飞",30);
        Student student2 = new Student("002","关羽",33);
        Student student3 = new Student("003","刘备",35);
        list.add(student1);
        list.add(student2);
        list.add(student3);
        do {
            System.out.println("                                      学生信息管理系统");
            System.out.println("1.遍历所有学生信息  2.增加学生信息  3.修改学生信息  4.删除学生信息  5.根据学号查找学生  6.根据姓名查找学生  7.退出");
            System.out.println("欢迎来到学生信息管理系统，请输入你要进行的操作对应的编号：");

            int num = action.nextInt();
            if (num == 1) {
                System.out.println("所有学生信息如下：");
                FindStudent.findAll(list);
            } else if (num == 2) {
                System.out.println("请输入所要增加的学生信息");
                System.out.println("学号是：");
                String code = action.next();
                System.out.println("姓名是：");
                String name = action.next();
                System.out.println("年龄是：");
                int age = action.nextInt();
                Student student = new Student(code,name,age);
                System.out.println("你所添加的学生信息为："+student.toString());
                list = AddStudent.add(list,student);
            } else if (num == 3) {
                System.out.println("请输入所要修改的学生的学号");
                //校验学号是否存在
                boolean isExit = false;
                String code = null;
                while(!isExit) {
                    code = action.next();
                    //调用方法判断学号是否存在
                    isExit = isCodeExit(list,code);
                }
                System.out.println("请输入你要修改的内容");
                System.out.println("修改后的学生学号是");
                String updateCode = action.next();
                System.out.println("修改后的学生姓名是");
                String updateName = action.next();
                System.out.println("修改后的学生年龄是");
                int updateAge = action.nextInt();
                Student student = new Student(updateCode,updateName,updateAge);
                System.out.println("你所修改的学生信息为"+student.toString());
                list = UpdateStudent.update(list,student,code);

            } else if (num == 4) {
                System.out.println("请输入所要删除的学生的学号");
                String code = null;
                //校验学号是否存在
                boolean isExit = false;
                while(!isExit) {
                    code = action.next();
                    isExit = isCodeExit(list,code);
                }
                list = DeleteStudent.delete(list,code);
                System.out.println("删除成功");

            } else if (num == 5) {
                System.out.println("请输入所要查找的学生的学号");
                String code = null;
                //校验学号是否存在
                boolean isExit = false;
                while(!isExit) {
                    code = action.next();
                    isExit = isCodeExit(list,code);
                }
                FindStudent.findByCode(list,code);

            } else if (num == 6) {
                System.out.println("请输入所要查找的学生的姓名");
                String name = null;
                //检验姓名是否存在
                boolean isExit = false;
                while(!isExit) {
                    name = action.next();
                    isExit = isNameExit(list,name);
                }
                FindStudent.findByName(list,name);
            } else if (num == 7) {
                System.out.println("欢迎下次光临！！！");
                break;
            } else {
                System.out.println("无此编号，请重新输入");
            }
        }while(true);
    }

    /**
     * 判断学号是否存在
     * @param list
     * @param code
     * @return
     */
    public static boolean isCodeExit(List<Student> list,String code){
        boolean isCodeExit = false;
        for (Student stu : list) {
            if (code.equals(stu.getCode())) {
                isCodeExit = true;
                break;
            }
        }
        if(!isCodeExit)
            System.out.println("你输入的学号不对，请重新输入");
        return isCodeExit;

    }

    /**
     * 判断姓名是否存在
     * @param list
     * @param name
     * @return
     */
    public static boolean isNameExit(List<Student> list,String name){
        boolean isNameExit = false;
        for (Student stu : list) {
            if (name.equals(stu.getName())) {
                isNameExit = true;
                break;
            }
        }
        if(!isNameExit)
            System.out.println("你输入的姓名不对，请重新输入");
        return isNameExit;

    }

}
