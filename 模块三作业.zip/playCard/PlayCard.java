package com.lagou.moduleThree.work.playCard;

import com.lagou.moduleThree.work.student.Student;

import java.util.*;

/**
 * 斗地主
 */
public class PlayCard {
    //花色数组
    private static final String[] color = {"♠","♣","♥","♦"};

    public static void main(String[] args) {
        //建立牌库
        List<Card> cardList = buildCard();
        //洗牌
        Collections.shuffle(cardList);
        //获取玩家的牌和底牌
        Map<String,List<Card>> cardMap = playerCard(cardList);
        //将玩家的牌按大小顺序输出
        System.out.println("玩家一号的牌");
        sort(cardMap.get("playOne"));
        System.out.println("玩家二号的牌");
        sort(cardMap.get("playTwo"));
        System.out.println("玩家三号的牌");
        sort(cardMap.get("playThree"));
        System.out.println("底牌");
        sort(cardMap.get("underCard"));

    }

    /**
     * 建立牌库
     * @return
     */
    public static List<Card> buildCard(){
        List<Card> cardList = new ArrayList<>();
        //建立一个牌库
        for (int i = 0; i < 4; i++) {//从花色开始循环
            for (int j = 0; j < 13; j++) {//每一种花色下面有13张牌
                Card card = new Card(j+1,color[i]);
                cardList.add(card);
            }
        }
        //大王小王固定花色和数字，小王黑桃14；大王红桃15
        Card smallCard = new Card(14,color[0]);
        Card bigCard = new Card(15,color[2]);
        cardList.add(smallCard);
        cardList.add(bigCard);
        return cardList;

    }

    /**
     * 返回三个玩家的牌和底牌
     * @param cardList
     * @return
     */
    public static Map<String,List<Card>> playerCard(List<Card> cardList){
        Map<String,List<Card>> cardMap = new HashMap<>();
        //用四个list来获取三个玩家的牌和底牌
        List<Card> playOne = new ArrayList<>();
        List<Card> playTwo = new ArrayList<>();
        List<Card> playThree = new ArrayList<>();
        List<Card> underCard = new ArrayList<>();
        //先获取底牌,最后三张牌
        underCard.add(cardList.get(cardList.size()-3));
        underCard.add(cardList.get(cardList.size()-2));
        underCard.add(cardList.get(cardList.size()-1));
        //获取三个玩家的牌，减去3的原因是除去底牌
        for(int i=1;i<cardList.size()+1-3;i++){
            //根据对3整除取余数的方法来获取牌
            if(i%3==1){
                playOne.add(cardList.get(i-1));
            }
            else if(i%3==2){
                playTwo.add(cardList.get(i-1));
            }
            else
                playThree.add(cardList.get(i-1));

        }
        //将三家牌和底牌放入map里边
        cardMap.put("playOne",playOne);
        cardMap.put("playTwo",playTwo);
        cardMap.put("playThree",playThree);
        cardMap.put("underCard",underCard);
        return cardMap;
    }

    /**
     * 将玩家的牌从大到小排序输出
     * @param list
     * @return
     */
    public static void sort(List<Card> list){
        //使用匿名内部类构造比较器
        Comparator<Card> comparator = new Comparator<Card>(){
            @Override
            public int compare(Card card, Card c1) {//card表示新加的对象，c1表示已有的对象
                //定义牌的大小规则,需要特殊处理牌的A和2
                //新加的牌面值是2
                if(card.getNumber()==2){
                    //分别讨论原有的对象的牌面值的情况
                    if(c1.getNumber()==14||c1.getNumber()==15)//14和15代表小王和大王
                        return 1;
                    else            //如果都是牌面值为2默认就是新加的对象大
                        return -1;
                }
                //新加的牌面值是A
                else if(card.getNumber()==1){
                    //分别讨论原有的对象的牌面值的情况
                    if(c1.getNumber()==2||c1.getNumber()==14||c1.getNumber()==15)//14和15代表小王和大王
                        return 1;
                    else            //如果都是牌面值为A默认就是新加的对象大
                        return -1;
                }
                //新加的牌面值是3-15
                else{
                    //分别讨论已有的对象的牌面值
                    //如果新对象的牌面值是3-k
                    if(card.getNumber()>=3&&card.getNumber()<=13){
                        //如果已有对像牌面值是2或者A或者大小王，新对象牌面值小
                        if(c1.getNumber()==2||c1.getNumber()==1||c1.getNumber()==14||c1.getNumber()==15)
                            return 1;
                        //如果已有对象牌面值是3-k
                        else if(card.getNumber()==c1.getNumber())//相等默认新加的大
                            return -1;
                        else                    //不相等就比较牌面值
                            return c1.getNumber()-card.getNumber();
                    }
                    //新对象是大王，直接返回1；
                    else if(card.getNumber()==15)
                        return -1;
                    //新对象是小王，看已有的对象是不是大王
                    else{
                        if(c1.getNumber()==15)
                            return 1;
                        else
                            return -1;
                    }
                }

            }
        };
        //定义一个treeSet，根据指定的比较器进行排序
        Set<Card> listCard = new TreeSet<>(comparator);
        for (Card ca:list) {
            listCard.add(ca);
        }
        System.out.println(listCard);

    }
}
