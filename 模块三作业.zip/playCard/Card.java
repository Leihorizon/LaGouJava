package com.lagou.moduleThree.work.playCard;

/**
 * 牌类
 */
public class Card {
    /**
     * 数字
     */
    private int number;
    /**
     * 花色
     */
    private String color;

    public Card(int number, String color) {
        this.number = number;
        this.color = color;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        String value = null;

        if(number == 1) {
            value = "A";
        }
        //大于10的牌变为JQK，14和15代表小王和大王
        else if(number > 10) {
            if(number == 11) {
                value = "J";
            } else if(number == 12) {
                value = "Q";
            } else if (number == 13) {
                value = "K";
            }else if(number == 14)
                value="小王";
            else if(number == 15)
                value="大王";

        }
        //小于10的牌变为相应的字符串
        else{
            value = String.valueOf(number);
        }
        //返回该张牌的信息,大王小王不用返回花色
        String strArr = null;
        if(value.equals("大王"))
            strArr="("+value + ")";
        else if(value.equals("小王"))
            strArr="("+value + ")";
        else
            strArr = "(" + color + value + ")";
        return strArr;

    }

}
