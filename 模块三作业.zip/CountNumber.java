package com.lagou.moduleThree.work;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 统计字符串"123,456,789,123,456"中每个数字字符串出现的次数并打印出来
 */
public class CountNumber {
    public static void main(String[] args) {
        String numArr = "123,456,789,123,456";
        Map<String,Integer> countMap = new HashMap<>();
        //将字符串按照','来切分成字符串数组
        String[] arr= numArr.split(",");
        //用list来接收字符串中不相同的字符串
        List<String> list = new ArrayList<>();
        //遍历数组，将不相同的字符串放入list中
        for (String str:arr) {
            if(!list.contains(str))
                list.add(str);
        }
        //对list里面的每一个字符串和字符串数组比较，统计出现次数，并放入map中
        for(String li:list){
            int count = 0;
            for(String str:arr){
                if(str.equals(li)){
                    count++;
                }
            }
            countMap.put(li,count);
        }
        //遍历map，统计次数
        for(Map.Entry<String, Integer> entry : countMap.entrySet()){
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key+"出现了"+value+"次");

        }
    }
}
